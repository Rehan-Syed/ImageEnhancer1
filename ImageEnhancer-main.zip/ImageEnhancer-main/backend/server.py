from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
import cv2
import numpy as np
from PIL import Image, ImageEnhance
import io
import os
import uuid
import rawpy
from typing import Optional, List
import logging
import base64

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create directories
os.makedirs("uploads", exist_ok=True)
os.makedirs("processed", exist_ok=True)

class EnhancementSettings(BaseModel):
    brightness: float = 0.0
    contrast: float = 1.0
    highlights: float = 0.0
    shadows: float = 0.0
    color_temperature: float = 0.0
    clarity: float = 0.0
    window_pull: float = 0.5

def detect_windows(image):
    """Detect bright window areas in the image"""
    try:
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Threshold to find very bright areas (potential windows)
        # Use adaptive threshold for better window detection
        _, bright_mask = cv2.threshold(blurred, 200, 255, cv2.THRESH_BINARY)
        
        # Morphological operations to clean up the mask
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 10))
        bright_mask = cv2.morphologyEx(bright_mask, cv2.MORPH_CLOSE, kernel)
        bright_mask = cv2.morphologyEx(bright_mask, cv2.MORPH_OPEN, kernel)
        
        # Find contours to identify window regions
        contours, _ = cv2.findContours(bright_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # Filter contours by area to get significant bright regions
        min_area = (image.shape[0] * image.shape[1]) * 0.01  # At least 1% of image
        window_mask = np.zeros_like(gray)
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > min_area:
                cv2.fillPoly(window_mask, [contour], 255)
        
        # Apply additional smoothing to the window mask
        window_mask = cv2.GaussianBlur(window_mask, (15, 15), 0)
        
        return window_mask.astype(np.float32) / 255.0
        
    except Exception as e:
        logger.error(f"Error in window detection: {str(e)}")
        return np.zeros((image.shape[0], image.shape[1]), dtype=np.float32)

def apply_window_pull(image, window_mask, pull_strength=0.5):
    """Apply selective tone mapping to window areas"""
    try:
        # Convert to float for processing
        img_float = image.astype(np.float32) / 255.0
        
        # Create adjustment factors based on window mask
        # Reduce exposure in window areas
        exposure_reduction = pull_strength * 0.7  # Max 70% reduction
        window_adjustment = 1.0 - (window_mask * exposure_reduction)
        
        # Apply per-channel adjustment
        for i in range(3):  # BGR channels
            img_float[:, :, i] *= window_adjustment
        
        # Apply selective contrast enhancement to window areas
        # This helps recover detail in blown-out windows
        window_contrast = 1.0 + (window_mask * pull_strength * 0.5)
        mean_val = np.mean(img_float, axis=(0, 1))
        
        for i in range(3):
            img_float[:, :, i] = ((img_float[:, :, i] - mean_val[i]) * 
                                 window_contrast[:, :, np.newaxis][:, :, 0] + mean_val[i])
        
        # Clip values and convert back
        img_float = np.clip(img_float, 0, 1)
        return (img_float * 255).astype(np.uint8)
        
    except Exception as e:
        logger.error(f"Error in window pull: {str(e)}")
        return image

def enhance_real_estate_image(image_array, settings=None):
    """Apply real estate specific image enhancements"""
    try:
        if settings is None:
            settings = EnhancementSettings()
        
        # Step 1: Detect windows
        logger.info("Detecting windows...")
        window_mask = detect_windows(image_array)
        
        # Step 2: Apply window pull if windows detected
        if np.max(window_mask) > 0.1:  # If significant window area detected
            logger.info("Applying window pull...")
            enhanced = apply_window_pull(image_array, window_mask, settings.window_pull)
        else:
            enhanced = image_array.copy()
        
        # Step 3: Convert to float for processing
        img_float = enhanced.astype(np.float32) / 255.0
        
        # Step 4: White Balance Correction (Gray World Algorithm)
        b, g, r = cv2.split(img_float)
        b_mean, g_mean, r_mean = np.mean(b), np.mean(g), np.mean(r)
        gray_mean = (b_mean + g_mean + r_mean) / 3
        
        if b_mean > 0 and g_mean > 0 and r_mean > 0:
            # Apply color temperature adjustment
            temp_factor = 1.0 + settings.color_temperature * 0.1
            b = b * (gray_mean / b_mean) * (1.0 + temp_factor * 0.1)
            g = g * (gray_mean / g_mean)
            r = r * (gray_mean / r_mean) * (1.0 - temp_factor * 0.1)
            img_float = cv2.merge([b, g, r])
        
        # Clip values
        img_float = np.clip(img_float, 0, 1)
        enhanced = (img_float * 255).astype(np.uint8)
        
        # Step 5: Apply brightness adjustment
        if settings.brightness != 0:
            enhanced = cv2.convertScaleAbs(enhanced, alpha=1.0, beta=settings.brightness * 50)
        
        # Step 6: Apply contrast adjustment
        if settings.contrast != 1.0:
            enhanced = cv2.convertScaleAbs(enhanced, alpha=settings.contrast, beta=0)
        
        # Step 7: Selective highlight/shadow adjustment
        if settings.highlights != 0 or settings.shadows != 0:
            # Convert to LAB for better highlight/shadow control
            lab = cv2.cvtColor(enhanced, cv2.COLOR_BGR2LAB)
            l, a, b = cv2.split(lab)
            
            # Shadow adjustment (affect darker areas)
            if settings.shadows != 0:
                shadow_mask = (255 - l) / 255.0  # Inverse of lightness
                shadow_adjustment = settings.shadows * 30 * shadow_mask
                l = np.clip(l.astype(np.float32) + shadow_adjustment, 0, 255).astype(np.uint8)
            
            # Highlight adjustment (affect brighter areas)
            if settings.highlights != 0:
                highlight_mask = l / 255.0
                highlight_adjustment = settings.highlights * -30 * highlight_mask
                l = np.clip(l.astype(np.float32) + highlight_adjustment, 0, 255).astype(np.uint8)
            
            enhanced = cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)
        
        # Step 8: CLAHE for adaptive contrast
        lab = cv2.cvtColor(enhanced, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        l = clahe.apply(l)
        enhanced = cv2.merge([l, a, b])
        enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)
        
        # Step 9: Clarity/Sharpening
        if settings.clarity != 0:
            # Unsharp mask for clarity
            gaussian = cv2.GaussianBlur(enhanced, (0, 0), 2.0)
            unsharp_mask = cv2.addWeighted(enhanced, 1.0 + settings.clarity, gaussian, -settings.clarity, 0)
            enhanced = unsharp_mask
        else:
            # Default sharpening
            kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
            sharpened = cv2.filter2D(enhanced, -1, kernel)
            enhanced = cv2.addWeighted(enhanced, 0.7, sharpened, 0.3, 0)
        
        # Step 10: Noise reduction
        enhanced = cv2.bilateralFilter(enhanced, 9, 75, 75)
        
        # Step 11: Final color enhancement
        enhanced_pil = Image.fromarray(cv2.cvtColor(enhanced, cv2.COLOR_BGR2RGB))
        enhancer = ImageEnhance.Color(enhanced_pil)
        enhanced_pil = enhancer.enhance(1.2)
        
        enhanced = cv2.cvtColor(np.array(enhanced_pil), cv2.COLOR_RGB2BGR)
        
        return enhanced, window_mask
        
    except Exception as e:
        logger.error(f"Error in real estate image enhancement: {str(e)}")
        return image_array, np.zeros((image_array.shape[0], image_array.shape[1]), dtype=np.float32)

def process_raw_image(file_content):
    """Process RAW image files"""
    try:
        with rawpy.imread(io.BytesIO(file_content)) as raw:
            rgb = raw.postprocess()
            return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    except Exception as e:
        logger.error(f"Error processing RAW image: {str(e)}")
        return None

def merge_hdr_images(image_files):
    """Merge multiple exposures into HDR image"""
    try:
        images = []
        for file_content in image_files:
            nparr = np.frombuffer(file_content, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is not None:
                images.append(img)
        
        if len(images) < 2:
            return None
        
        # Align images - fix the OpenCV API usage
        alignMTB = cv2.createAlignMTB()
        aligned_images = []
        
        # Use the first image as reference and align others to it
        reference_img = images[0]
        aligned_images.append(reference_img)
        
        for i in range(1, len(images)):
            aligned_img = np.zeros_like(reference_img)
            alignMTB.process(images[i], aligned_img)
            aligned_images.append(aligned_img)
        
        # Alternative: Skip alignment for now if it causes issues
        # aligned_images = images
        
        # Create HDR using exposure fusion (more robust than Debevec)
        merge_mertens = cv2.createMergeMertens()
        hdr = merge_mertens.process(aligned_images)
        
        # Convert to 8-bit directly (Mertens already produces LDR)
        hdr = np.clip(hdr * 255, 0, 255).astype(np.uint8)
        
        return hdr
        
    except Exception as e:
        logger.error(f"Error in HDR processing: {str(e)}")
        # Fallback: return the first image with enhancement
        if len(images) > 0:
            return images[0]
        return None

@app.get("/api/health")
async def health_check():
    return {"status": "healthy"}

@app.post("/api/enhance-image")
async def enhance_image_endpoint(file: UploadFile = File(...)):
    # Validate file type first
    allowed_extensions = {'.jpg', '.jpeg', '.png', '.tiff', '.tif', '.cr2', '.nef', '.arw', '.dng'}
    allowed_mime_types = {'image/jpeg', 'image/jpg', 'image/png', 'image/tiff', 'image/tif'}
    
    file_extension = os.path.splitext(file.filename.lower())[1] if file.filename else ''
    
    if file_extension not in allowed_extensions and file.content_type not in allowed_mime_types:
        raise HTTPException(
            status_code=400, 
            detail=f"Unsupported file format. Supported formats: JPG, PNG, TIFF, CR2, NEF, ARW, DNG"
        )
    
    try:
        file_content = await file.read()
        
        if not file_content:
            raise HTTPException(status_code=400, detail="Empty file uploaded")
        
        # Process based on file type
        if file_extension in {'.cr2', '.nef', '.arw', '.dng'}:
            image_array = process_raw_image(file_content)
            if image_array is None:
                raise HTTPException(status_code=400, detail="Failed to process RAW image")
        else:
            nparr = np.frombuffer(file_content, np.uint8)
            image_array = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            
            if image_array is None:
                raise HTTPException(status_code=400, detail="Invalid image file")
        
        # Generate unique filename
        file_id = str(uuid.uuid4())
        
        # Save original image
        original_path = f"uploads/original_{file_id}.jpg"
        cv2.imwrite(original_path, image_array)
        
        # Apply real estate enhancement
        enhanced_image, window_mask = enhance_real_estate_image(image_array)
        
        # Save enhanced image
        enhanced_path = f"processed/enhanced_{file_id}.jpg"
        cv2.imwrite(enhanced_path, enhanced_image, [cv2.IMWRITE_JPEG_QUALITY, 95])
        
        # Convert images to base64
        def image_to_base64(img_path):
            with open(img_path, "rb") as img_file:
                return base64.b64encode(img_file.read()).decode('utf-8')
        
        # Convert window mask to base64 for debugging
        window_mask_img = (window_mask * 255).astype(np.uint8)
        window_mask_path = f"processed/window_mask_{file_id}.jpg"
        cv2.imwrite(window_mask_path, window_mask_img)
        
        original_b64 = image_to_base64(original_path)
        enhanced_b64 = image_to_base64(enhanced_path)
        window_mask_b64 = image_to_base64(window_mask_path)
        
        return {
            "success": True,
            "file_id": file_id,
            "original_image": f"data:image/jpeg;base64,{original_b64}",
            "enhanced_image": f"data:image/jpeg;base64,{enhanced_b64}",
            "window_mask": f"data:image/jpeg;base64,{window_mask_b64}",
            "windows_detected": bool(np.max(window_mask) > 0.1),
            "download_url": f"/api/download/{file_id}",
            "settings": {
                "brightness": 0.0,
                "contrast": 1.0,
                "highlights": 0.0,
                "shadows": 0.0,
                "color_temperature": 0.0,
                "clarity": 0.0,
                "window_pull": 0.5
            }
        }
        
    except Exception as e:
        logger.error(f"Error processing image: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

@app.post("/api/enhance-with-settings")
async def enhance_with_settings(request_data: dict):
    """Re-enhance image with custom settings"""
    try:
        file_id = request_data.get('file_id')
        settings_data = request_data.get('settings', {})
        
        if not file_id:
            raise HTTPException(status_code=400, detail="file_id is required")
        
        # Create settings object
        settings = EnhancementSettings(**settings_data)
        
        original_path = f"uploads/original_{file_id}.jpg"
        
        if not os.path.exists(original_path):
            raise HTTPException(status_code=404, detail="Original image not found")
        
        # Load original image
        image_array = cv2.imread(original_path)
        
        # Apply enhancement with custom settings
        enhanced_image, window_mask = enhance_real_estate_image(image_array, settings)
        
        # Save enhanced image
        enhanced_path = f"processed/enhanced_{file_id}.jpg"
        cv2.imwrite(enhanced_path, enhanced_image, [cv2.IMWRITE_JPEG_QUALITY, 95])
        
        # Convert to base64
        with open(enhanced_path, "rb") as img_file:
            enhanced_b64 = base64.b64encode(img_file.read()).decode('utf-8')
        
        return {
            "success": True,
            "enhanced_image": f"data:image/jpeg;base64,{enhanced_b64}",
            "windows_detected": bool(np.max(window_mask) > 0.1)
        }
        
    except Exception as e:
        logger.error(f"Error re-enhancing image: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error re-enhancing image: {str(e)}")

@app.post("/api/enhance-hdr")
async def enhance_hdr_endpoint(files: List[UploadFile] = File(...)):
    """Process HDR images (3+ exposures)"""
    try:
        if len(files) < 2:
            raise HTTPException(status_code=400, detail="HDR processing requires at least 2 images")
        
        # Read all files
        file_contents = []
        for file in files:
            content = await file.read()
            file_contents.append(content)
        
        # Merge HDR
        hdr_result = merge_hdr_images(file_contents)
        
        if hdr_result is None:
            raise HTTPException(status_code=400, detail="Failed to process HDR images")
        
        # Generate unique filename
        file_id = str(uuid.uuid4())
        
        # Apply real estate enhancement to HDR result
        enhanced_image, window_mask = enhance_real_estate_image(hdr_result)
        
        # Save images
        hdr_path = f"processed/hdr_{file_id}.jpg"
        enhanced_path = f"processed/enhanced_hdr_{file_id}.jpg"
        
        cv2.imwrite(hdr_path, hdr_result, [cv2.IMWRITE_JPEG_QUALITY, 95])
        cv2.imwrite(enhanced_path, enhanced_image, [cv2.IMWRITE_JPEG_QUALITY, 95])
        
        # Convert to base64
        def image_to_base64(img_path):
            with open(img_path, "rb") as img_file:
                return base64.b64encode(img_file.read()).decode('utf-8')
        
        hdr_b64 = image_to_base64(hdr_path)
        enhanced_b64 = image_to_base64(enhanced_path)
        
        return {
            "success": True,
            "file_id": file_id,
            "hdr_image": f"data:image/jpeg;base64,{hdr_b64}",
            "enhanced_image": f"data:image/jpeg;base64,{enhanced_b64}",
            "windows_detected": bool(np.max(window_mask) > 0.1),
            "download_url": f"/api/download-hdr/{file_id}"
        }
        
    except Exception as e:
        logger.error(f"Error processing HDR: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error processing HDR: {str(e)}")

@app.get("/api/download/{file_id}")
async def download_enhanced_image(file_id: str):
    try:
        enhanced_path = f"processed/enhanced_{file_id}.jpg"
        
        if not os.path.exists(enhanced_path):
            raise HTTPException(status_code=404, detail="Enhanced image not found")
        
        return FileResponse(
            enhanced_path,
            media_type="image/jpeg",
            filename=f"real_estate_enhanced_{file_id}.jpg"
        )
        
    except Exception as e:
        logger.error(f"Error downloading image: {str(e)}")
        raise HTTPException(status_code=500, detail="Error downloading image")

@app.get("/api/download-hdr/{file_id}")
async def download_hdr_image(file_id: str):
    try:
        enhanced_path = f"processed/enhanced_hdr_{file_id}.jpg"
        
        if not os.path.exists(enhanced_path):
            raise HTTPException(status_code=404, detail="HDR image not found")
        
        return FileResponse(
            enhanced_path,
            media_type="image/jpeg",
            filename=f"real_estate_hdr_{file_id}.jpg"
        )
        
    except Exception as e:
        logger.error(f"Error downloading HDR image: {str(e)}")
        raise HTTPException(status_code=500, detail="Error downloading HDR image")

@app.on_event("startup")
async def startup_event():
    logger.info("Real Estate Image Enhancer API started successfully")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)