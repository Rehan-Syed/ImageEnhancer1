import React, { useState, useRef } from 'react';
import './App.css';

function App() {
  const [dragActive, setDragActive] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [mode, setMode] = useState('single'); // 'single', 'hdr', 'batch'
  const [files, setFiles] = useState([]);
  const [settings, setSettings] = useState({
    brightness: 0.0,
    contrast: 1.0,
    highlights: 0.0,
    shadows: 0.0,
    color_temperature: 0.0,
    clarity: 0.0,
    window_pull: 0.5
  });
  const fileInputRef = useRef(null);

  const backendUrl = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    if (mode === 'single' && droppedFiles.length > 0) {
      handleFile(droppedFiles[0]);
    } else if (mode === 'hdr' && droppedFiles.length >= 2) {
      handleHDRFiles(droppedFiles);
    } else if (mode === 'batch') {
      handleBatchFiles(droppedFiles);
    }
  };

  const handleFileInput = (e) => {
    const selectedFiles = Array.from(e.target.files);
    if (mode === 'single' && selectedFiles.length > 0) {
      handleFile(selectedFiles[0]);
    } else if (mode === 'hdr' && selectedFiles.length >= 2) {
      handleHDRFiles(selectedFiles);
    } else if (mode === 'batch') {
      handleBatchFiles(selectedFiles);
    }
  };

  const validateFile = (file) => {
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/tiff', 'image/tif'];
    const allowedExtensions = ['.cr2', '.nef', '.arw', '.dng'];
    const fileExtension = file.name.toLowerCase().substring(file.name.lastIndexOf('.'));
    
    if (!allowedTypes.includes(file.type) && !allowedExtensions.includes(fileExtension)) {
      return 'Unsupported file format';
    }
    
    if (file.size > 50 * 1024 * 1024) {
      return 'File size must be less than 50MB';
    }
    
    return null;
  };

  const handleFile = async (file) => {
    const validation = validateFile(file);
    if (validation) {
      setError(validation);
      return;
    }

    setError(null);
    setResult(null);
    setProcessing(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${backendUrl}/api/enhance-image`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to process image');
      }

      const data = await response.json();
      setResult(data);
      setSettings(data.settings);
    } catch (err) {
      setError(err.message || 'Failed to process image. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const handleHDRFiles = async (hdrFiles) => {
    if (hdrFiles.length < 2) {
      setError('HDR processing requires at least 2 images');
      return;
    }

    for (let file of hdrFiles) {
      const validation = validateFile(file);
      if (validation) {
        setError(`${file.name}: ${validation}`);
        return;
      }
    }

    setError(null);
    setResult(null);
    setProcessing(true);

    try {
      const formData = new FormData();
      hdrFiles.forEach(file => {
        formData.append('files', file);
      });

      const response = await fetch(`${backendUrl}/api/enhance-hdr`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Failed to process HDR images');
      }

      const data = await response.json();
      setResult({ ...data, isHDR: true });
    } catch (err) {
      setError(err.message || 'Failed to process HDR images. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const handleBatchFiles = async (batchFiles) => {
    // Process files one by one for batch processing
    setFiles(batchFiles);
    setError(null);
    setProcessing(true);
    
    // For now, just process the first file - full batch processing would be more complex
    if (batchFiles.length > 0) {
      await handleFile(batchFiles[0]);
    }
  };

  const handleSettingChange = async (setting, value) => {
    if (!result || !result.file_id) return;

    const newSettings = { ...settings, [setting]: value };
    setSettings(newSettings);

    try {
      const response = await fetch(`${backendUrl}/api/enhance-with-settings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          file_id: result.file_id,
          settings: newSettings
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to apply settings');
      }

      const data = await response.json();
      setResult(prev => ({ ...prev, enhanced_image: data.enhanced_image }));
    } catch (err) {
      console.error('Error applying settings:', err);
    }
  };

  const handleDownload = () => {
    if (result && result.download_url) {
      const link = document.createElement('a');
      link.href = `${backendUrl}${result.download_url}`;
      link.download = result.isHDR ? 
        `real_estate_hdr_${result.file_id}.jpg` : 
        `real_estate_enhanced_${result.file_id}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const resetApp = () => {
    setResult(null);
    setError(null);
    setProcessing(false);
    setFiles([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const SliderControl = ({ label, value, onChange, min = -1, max = 1, step = 0.1 }) => (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="text-sm font-medium text-gray-700">{label}</label>
        <span className="text-sm text-gray-500">{value.toFixed(1)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
      />
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-2 rounded-lg">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                </svg>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Real Estate Image Enhancer</h1>
                <p className="text-sm text-gray-600">Professional window pull & tone mapping for real estate photography</p>
              </div>
            </div>
            
            {/* Mode Selection */}
            <div className="flex space-x-2">
              {['single', 'hdr', 'batch'].map((modeOption) => (
                <button
                  key={modeOption}
                  onClick={() => setMode(modeOption)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    mode === modeOption
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  {modeOption === 'single' ? 'Single Image' : 
                   modeOption === 'hdr' ? 'HDR (2-3 images)' : 'Batch Process'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!result ? (
          <div className="max-w-4xl mx-auto">
            {/* Hero Section */}
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Perfect Your Real Estate Photos
              </h2>
              <p className="text-xl text-gray-600 mb-8">
                Advanced window detection, tone mapping, and HDR processing designed specifically for real estate photography
              </p>
              <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500">
                <span className="bg-white px-3 py-1 rounded-full border shadow-sm">✓ Smart Window Detection</span>
                <span className="bg-white px-3 py-1 rounded-full border shadow-sm">✓ Automatic Window Pull</span>
                <span className="bg-white px-3 py-1 rounded-full border shadow-sm">✓ HDR Processing</span>
                <span className="bg-white px-3 py-1 rounded-full border shadow-sm">✓ Interactive Controls</span>
              </div>
            </div>

            {/* Upload Area */}
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <div
                className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-200 ${
                  dragActive
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              >
                {processing ? (
                  <div className="space-y-4">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                    <div>
                      <p className="text-lg font-medium text-gray-900">
                        {mode === 'hdr' ? 'Processing HDR images...' : 'Analyzing your image...'}
                      </p>
                      <p className="text-sm text-gray-500">
                        {mode === 'hdr' ? 'Merging exposures and applying tone mapping' : 'Detecting windows and applying enhancements'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="bg-gray-100 rounded-full p-4 w-16 h-16 mx-auto">
                      <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-lg font-medium text-gray-900 mb-2">
                        {mode === 'single' ? 'Drop your real estate photo here' :
                         mode === 'hdr' ? 'Drop 2-3 bracketed exposures here' :
                         'Drop multiple images for batch processing'}
                      </p>
                      <p className="text-sm text-gray-500 mb-4">
                        or click to browse files
                      </p>
                      <button
                        onClick={() => fileInputRef.current?.click()}
                        className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-lg font-medium hover:from-blue-700 hover:to-indigo-700 transition-all duration-200 transform hover:scale-105"
                      >
                        Choose Files
                      </button>
                    </div>
                    <div className="text-xs text-gray-400 space-y-1">
                      <p>Supported formats: JPG, PNG, TIFF, CR2, NEF, ARW, DNG</p>
                      <p>Maximum file size: 50MB per image</p>
                      {mode === 'hdr' && <p className="font-medium text-blue-600">HDR: Upload 2-3 different exposures of the same scene</p>}
                    </div>
                  </div>
                )}
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,.cr2,.nef,.arw,.dng"
                multiple={mode !== 'single'}
                onChange={handleFileInput}
                className="hidden"
              />

              {error && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center">
                    <svg className="w-5 h-5 text-red-600 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <p className="text-red-800">{error}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Results Section */
          <div className="space-y-8">
            {/* Header */}
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                {result.isHDR ? 'HDR Processing Complete!' : 'Enhancement Complete!'}
              </h2>
              <p className="text-gray-600">
                {result.windows_detected 
                  ? 'Windows detected and enhanced with professional tone mapping'
                  : 'Image enhanced with professional real estate processing'}
              </p>
              {result.windows_detected && (
                <div className="mt-2 inline-flex items-center px-3 py-1 rounded-full text-sm bg-green-100 text-green-800">
                  <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Window Pull Applied
                </div>
              )}
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Image Comparison */}
              <div className="lg:col-span-2">
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <h3 className="text-lg font-semibold text-gray-900 text-center">
                        {result.isHDR ? 'HDR Merged' : 'Original'}
                      </h3>
                      <div className="aspect-w-16 aspect-h-12 bg-gray-100 rounded-lg overflow-hidden">
                        <img
                          src={result.isHDR ? result.hdr_image : result.original_image}
                          alt={result.isHDR ? 'HDR Merged' : 'Original'}
                          className="w-full h-full object-contain"
                        />
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h3 className="text-lg font-semibold text-gray-900 text-center">Enhanced</h3>
                      <div className="aspect-w-16 aspect-h-12 bg-gray-100 rounded-lg overflow-hidden">
                        <img
                          src={result.enhanced_image}
                          alt="Enhanced"
                          className="w-full h-full object-contain"
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Window Mask Debug */}
                  {result.window_mask && result.windows_detected && (
                    <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                      <h4 className="text-sm font-medium text-gray-700 mb-2">Window Detection Map</h4>
                      <div className="w-32 h-24 bg-gray-100 rounded overflow-hidden">
                        <img
                          src={result.window_mask}
                          alt="Window Mask"
                          className="w-full h-full object-contain"
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">White areas show detected windows</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Interactive Controls */}
              {!result.isHDR && (
                <div className="space-y-6">
                  <div className="bg-white rounded-2xl shadow-lg p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Fine-Tune Settings</h3>
                    <div className="space-y-4">
                      <SliderControl
                        label="Window Pull"
                        value={settings.window_pull}
                        onChange={(value) => handleSettingChange('window_pull', value)}
                        min={0}
                        max={1}
                      />
                      <SliderControl
                        label="Brightness"
                        value={settings.brightness}
                        onChange={(value) => handleSettingChange('brightness', value)}
                      />
                      <SliderControl
                        label="Contrast"
                        value={settings.contrast}
                        onChange={(value) => handleSettingChange('contrast', value)}
                        min={0.5}
                        max={2}
                      />
                      <SliderControl
                        label="Highlights"
                        value={settings.highlights}
                        onChange={(value) => handleSettingChange('highlights', value)}
                      />
                      <SliderControl
                        label="Shadows"
                        value={settings.shadows}
                        onChange={(value) => handleSettingChange('shadows', value)}
                      />
                      <SliderControl
                        label="Color Temperature"
                        value={settings.color_temperature}
                        onChange={(value) => handleSettingChange('color_temperature', value)}
                      />
                      <SliderControl
                        label="Clarity"
                        value={settings.clarity}
                        onChange={(value) => handleSettingChange('clarity', value)}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={handleDownload}
                className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-8 py-3 rounded-lg font-medium hover:from-green-700 hover:to-emerald-700 transition-all duration-200 transform hover:scale-105 flex items-center justify-center space-x-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <span>Download Enhanced Image</span>
              </button>
              <button
                onClick={resetApp}
                className="bg-gray-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-gray-700 transition-all duration-200 flex items-center justify-center space-x-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
                <span>Process Another Image</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2025 Real Estate Image Enhancer. Professional real estate photography made simple.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;